import React, { useRef as useR } from "react";
import { SafeAreaView, ScrollView, Text, StyleSheet, View, ImageBackground, Animated, useWindowDimensions} from "react-native";

const MyComponent = () => {

  const images = [
    'https://images.wallpaperscraft.ru/image/single/most_svai_tuman_1207678_1280x720.jpg',
    'https://images.wallpaperscraft.ru/image/single/doroga_sneg_derevia_1207624_1280x720.jpg',
    'https://images.wallpaperscraft.ru/image/single/gory_dolina_ovtsy_1207416_1280x720.jpg',
    'https://images.wallpaperscraft.ru/image/single/zemlia_zvezdy_svechenie_1207423_1280x720.jpg'
    ];

  const scrollAnim = useR(new Animated.Value(0)).current;
  const { width: winWidth } = useWindowDimensions();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.mainContainer}>
        <ScrollView
          horizontal={true}
          style={styles.scrollStyle}
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={Animated.event([
            {
              nativeEvent: {
                contentOffset: {
                  x: scrollAnim
                }
              }
            }
          ])}
          scrollEventThrottle={1}
        >
          {images.map((image, imageIndex) => (
            <View style={{ width: winWidth, height: 250 }} key={imageIndex}>
              <ImageBackground source={{ uri: image }} style={styles.imageCard}>
                <View style={styles.textContent}>
                  <Text style={styles.infoText}>
                  {"Image" + imageIndex}
                  </Text>
                </View>
              </ImageBackground>
            </View>
          ))}
        </ScrollView>
        <View style={styles.dotContainer}>
          {images.map((image, imageIndex) => {
            const dotWidth = scrollAnim.interpolate({
              inputRange: [
                winWidth * (imageIndex - 1),
                winWidth * imageIndex,
                winWidth * (imageIndex + 1)
              ],
              outputRange: [8, 16, 8],
              extrapolate: "clamp"
            });

            return (
              <Animated.View key={imageIndex} style={[styles.dot, { width: dotWidth }]} />
            );
          })}
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#f0f0f0"
  },
  mainContainer: {
    height: 300,
    alignItems: "center",
    justifyContent: "center"
  },
  imageCard: {
    flex: 1,
    marginVertical: 4,
    marginHorizontal: 16,
    borderRadius: 10,
    overflow: "hidden",
    justifyContent: "center",
    alignItems: "center"
  },
  textContent: {
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    paddingHorizontal: 24,
    paddingVertical: 8,
    borderRadius: 5
  },
  infoText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold"
  },
  dotContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10
  },
  dot: {
    height: 8,
    width: 8,
    borderRadius: 4,
    backgroundColor: "#999",
    marginHorizontal: 4
  }
});

export default MyComponent;

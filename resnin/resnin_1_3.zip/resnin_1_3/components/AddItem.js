

const AddItem = ({items, setItems}) => {
    const [text, setText] = useState('');
    const [currId, setCurrId] = useState(0)

    const addItem = () => {
        if (text.length) {
          setItems([...items, { id: currId, text: text }])
          setCurrId(currId + 1)
          setText('');
        }
      };

    return (
        <>
            <TextInput
                style={styles.input}
                placeholder="Task"
                value={text}
                onChangeText={(value) => setText(value)}
            />
            <Button title="Add" onPress={() => addItem()} />
        </>
    )
}

export default AddItem
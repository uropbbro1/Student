import React from 'react';
import {
    StyleSheet,
    Text,
} from 'react-native';


const TaskItem = ({setItems, text, items, item}) => {

    const removeItem = (item) => {
        setItems([...items.filter(el => el.id !== item.id)])
    };

    return <Text onPress={() => removeItem(item)} style={styles.item}>{text}</Text>
}


const styles = StyleSheet.create({
    item: {
      fontSize: 16,
      padding: 5,
      borderColor: 'green',
      borderWidth: 1,
      margin: 10,
    },
  });

export default TaskItem


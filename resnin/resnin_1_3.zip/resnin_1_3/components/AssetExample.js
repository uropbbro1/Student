import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
} from 'react-native';
import TaskItem from './TaskItem';
import AddItem from './AddItem';

const AssetExample = () => {
  const [items, setItems] = useState([]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>TODO LIST</Text>

      <AddItem items={items} setItems={setItems} />

      <Text style={styles.title}>List</Text>
      
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskItem text={item.text} item={item} setItems={setItems} items={items}/>
        )}
      />
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fafafa',
    padding: 20,
    height: '100%'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    marginTop: 20,
  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: 'blue',
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  item: {
    fontSize: 16,
    padding: 5,
    borderColor: 'green',
    borderWidth: 1,
    margin: 10,
  },
});

export default AssetExample;

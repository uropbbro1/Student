import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Button,
  FlatList,
  Image,
  Alert,
} from 'react-native';

const AssetExample = () => {
  const [items, setItems] = useState([]);
  const [text, setText] = useState('');
  const [currId, setCurrId] = useState(0)

  const addItem = () => {
    if (text.length) {
      setItems(prev => prev.push({ id: currId, text: text }));
      setCurrId(prev => prev++)
      setText('');
    }
  };

  const removeItem = (item) => {
    setItems(prev => prev.filter(el => el.id !== item.id))
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>TODO LIST</Text>
      <TextInput
        style={styles.input}
        placeholder="Task"
        value={text}
        onChangeText={(value) => setText(value)}
      />
      <Button title="Add" onPress={addItem()} />
      <Text style={styles.title}>List</Text>
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Text onPress={removeItem(item)} style={styles.item}>{item.text}</Text>
        )}
      />
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    marginTop: 20,
  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: 'red',
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  item: {
    fontSize: 16,
    padding: 5,
    borderColor: 'blue',
    borderWidth: 1,
    margin: 10,
  },
});

export default AssetExample;

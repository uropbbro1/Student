import {StyleSheet, Text, View, TextInput, Button, Image, Alert, Pressable} from 'react-native';
import {useState} from "react";


const Register = ({navigation}) => {
    const [login, onChangeLogin] = useState('');
    const [password, onChangePassword] = useState('');

    return (
        <View style={styles.container}>
        <Image style={styles.image}
            source={require('../assets/letter.png')}
        />

            <Text style={styles.title}>
                Регистрация
            </Text>
            <TextInput
                style={styles.input}
                onChangeText={onChangeLogin}
                value={login}
                placeholder="Email"
                keyboardType="email-address"
            />
            <TextInput
                style={styles.input}
                onChangeText={onChangePassword}
                value={password}
                placeholder="Пароль"
                secureTextEntry={true}
                keyboardType="invisible-password"
            />
            <TextInput
                style={styles.input}
                onChangeText={onChangePassword}
                value={password}
                placeholder="Пароль ещё раз"
                secureTextEntry={true}
                keyboardType="invisible-password"
            />
            <Pressable style={styles.button} onPress={() => {Alert.alert('Регистрация', 'Успешно!'); navigation.navigate('List')}}>
                <Text style={styles.text} >Зарегистрироваться</Text>
            </Pressable>

        </View>

    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
        display: 'flex',
        alignItems: 'center'
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        marginTop: 20,
    },
    description: {
        textAlign: "center",
        marginBottom: 20
    },
    input: {
        width: '80%',
        height: 40,
        margin: 12,
        borderWidth: 1,
        padding: 10,
        borderRadius: 8,
    },
    item: {
        fontSize: 16,
        marginBottom: 5,
    },
    image: {
        width: 200,
        height: 200,
        marginEnd: 'auto',
        marginStart: 'auto',
    },
    button: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        paddingHorizontal: 32,
        borderRadius: 4,
        borderStyle: 'solid',
        backgroundColor: 'white',
    },
});

export default Register;
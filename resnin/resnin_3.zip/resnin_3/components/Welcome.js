
import { Text, Button, View, StyleSheet, Image } from "react-native"


export default Welcome = ({navigation}) => {

    return (
        <View style={styles.container}>
            <Image style={styles.image}
                source={require('../assets/letter.png')}
            />
            <Text style={styles.text}>
                Добро пожаловать!
            </Text>
            <Button title="Начать" onPress={() => navigation.navigate('Register')}/> 
        </View>
    )
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
        display: 'flex',
        alignItems: 'center'
    },
    text: {
        alignItems: 'center',
        fontSize: 30,
        marginBottom: 20
    },
});
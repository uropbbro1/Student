import React, { useEffect, useRef as useR, useState } from "react";
import {Text, StyleSheet, View} from "react-native";
import AppNavigator from './src/navigation/Navigator'
import * as Font from 'expo-font'
import AppLoading from 'expo'
import {statusBar} from 'expo-status-bar'

const App = () => {

  const [isFontLoaded, setIsFontLoaded] = useState(false)

  const loadFont = async () => {
    await Font.loadAsync({
      'Regular': require('./src/fonts/Roboto-Regular.ttf'),
      'Bold': require('./src/fonts/Roboto-Bold.ttf')
    })
    setIsFontLoaded(true)
  }

  useEffect(() => {
    loadFont()
  }, [])

  return (
    (isFontLoaded === true) ? (<AppNavigator/>) : (AppLoading)
  )
};

const styles = StyleSheet.create({
  
});

export default App;

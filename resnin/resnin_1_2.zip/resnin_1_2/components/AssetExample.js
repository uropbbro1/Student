import { Text, View, StyleSheet } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.text}>
          "Кадиш.com" Натан Ингландер{'\n'}
          Издательство "Книжки"
        </Text>
      </View>
      <View style={styles.textContainer}>
        <Text>
          Существует достаточно много вредных привычек, которые мешают нам становится лучше, тормозят наш рост и развитие. 
          И это не только те самые вредные привычки, о которых часто говорят диетологи и врачи. 
          Часто это именно психологические проблемы, от которых, если поработать над собой, можно избавиться самостоятельно.
      </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: "#d3d3d3",
    padding: 0,
  },
  text:
  {
    textAlign: "center",
    fontSize: 24,
    paddingBottom: 40,
  },
  textContainer:
  {
    height: '80%',
    textAlign: "center",
    padding: 15,
    fontSize: 18,
    margin: 'auto',
    backgroundColor: "#a9a9a9",
    paddingBottom: 100
  }
});

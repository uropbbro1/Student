import * as React from 'react';
import { Button, View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';

function First({navigation}) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Первый экран</Text>
      <View>
        <Button
          style = {{padding: 5}}
          title="Второй экран"
          onPress={() => navigation.navigate('Second')}
        />
      </View>
    </View>
  );
}

function Second({navigation}) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Второй экран</Text>
      <View>
        <Button
          style = {{padding: 5}}
          title="Третий экран"
          onPress={() => navigation.navigate('Third')}
        />
        <Button
          style = {{padding: 5}}
          title="Назад"
          onPress={() => navigation.navigate('First')}
        />
      </View>
    </View>
  );
}
function Third({navigation}) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Text>Третий экран</Text>
      <View>
        <Button
          style = {{padding: 5}}
          title="Назад"
          onPress={() => navigation.navigate('Second')}
        />
      </View>
    </View>
  );
}




function App() {

  const Drawer = createDrawerNavigator();

  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="First">
        <Drawer.Screen name="First" component={First} />
        <Drawer.Screen name="Second" component={Second} />
        <Drawer.Screen name="Third" component={Third} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

export default App;

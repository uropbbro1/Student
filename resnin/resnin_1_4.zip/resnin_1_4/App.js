import * as React from 'react';
import { Button, View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';

function First() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Первый экран</Text>
      <View>
        <Button
          style = {{padding: 5}}
          title="Второй экран"
          onPress={() => navigation.navigate('Second')}
        />
      </View>
    </View>
  );
}

function Second() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Второй экран</Text>
      <View>
        <Button
          style = {{padding: 5}}
          title="Третий экран"
          onPress={() => navigation.navigate('Third')}
        />
        <Button
          style = {{padding: 5}}
          title="Назад"
          onPress={() => navigation.navigate('First')}
        />
      </View>
    </View>
  );
}
function Third() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Text>Второй экран</Text>
      <View>
        <Button
          style = {{padding: 5}}
          title="Назад"
          onPress={() => navigation.navigate('Second')}
        />
      </View>
    </View>
  );
}

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="First">
        <Stack.Screen name="First" component={First} />
        <Stack.Screen name="Second" component={Second} />
        <Stack.Screen name="Third" component={Third} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;

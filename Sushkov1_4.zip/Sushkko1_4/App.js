import { Button, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

function MainScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Welcome to the Transportation Hub</Text>
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Cars')}>
          <Text>Cars</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Airplane')}>
          <Text>Airplane</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Ship')}>
          <Text>Ship</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  buttonContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#afeeee',
    padding: 10,
    margin: 5,
  },
});
function Car() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Image source={require('./assets/Cars.png')} 
        style={{ height: 255, resizeMode: 'cover', marginTop: 50, width: 350 }}/>
      <Text>The fastest car in the world, Thrust SSC, set the land speed record in 1997, reaching an incredible speed of 1228 kilometers per hour (763 miles per hour).</Text>
    </View>
  );
}

function AirplaneDetails() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
    <Image source={require('./assets/Airplane.png')} 
        style={{ height: 255, resizeMode: 'cover', marginTop: 50, width: 350 }}/>
      <Text>The Airbus A380, one of the largest in the world, has a maximum takeoff weight of around 1.2 million pounds.</Text>
    </View>
  );
}

function ShipDetails() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
    <Image source={require('./assets/Ship.png')} 
        style={{ height: 255, resizeMode: 'cover', marginTop: 50, width: 350 }}/>
      <Text>There is a ship called the "Seawise Giant," considered the largest ship in history. It has a length of 458 meters.</Text>
    </View>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={MainScreen} />
        <Stack.Screen name="Cars" component={Car} />
        <Stack.Screen name="Airplane" component={AirplaneDetails} />
        <Stack.Screen name="Ship" component={ShipDetails} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

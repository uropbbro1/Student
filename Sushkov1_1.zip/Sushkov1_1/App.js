import { StyleSheet, Text, View, Image, Button, Alert } from 'react-native';

const MyCustomComponent = () => {
  return (
    <View style={styles.wrapper}>
      <Text style={styles.title}>Bright Magazine</Text>
      <View style={styles.card}>
        <Text style={styles.category}>News</Text>
        <Image 
          source={{ uri: 'https://brightmagazine.ru/wp-content/uploads/2023/11/brooke-cagle-uHVRvDr7pg-unsplash-768x512.jpg' }}
          style={styles.image}
        />
        <View>
          <Text style={styles.articleTitle}>Как научиться делегировать задачи?</Text>
          <Text>
            Если вы индивидуальный предприниматель и никогда не задумывались о делегировании задач, возможно вы совершаете ошибку.
          </Text>
          <Button 
            onPress={() => Alert.alert("Button Clicked")}
            title="Read more..."
            color='green'
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: { flex: 1, backgroundColor: '#F9F9F9' },
  title: { marginTop: 100, textAlign: 'center', fontSize: 24, fontWeight: 'bold' },
  card: { backgroundColor:  '#FFFFFF', margin: 10, padding: 12, borderRadius: 8, elevation: 5 },
  category: { color: 'navy' },
  articleTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 8 },
  image: { width: '100%', height: 200, marginTop: 16, marginBottom: 8 }
});

export default MyCustomComponent;

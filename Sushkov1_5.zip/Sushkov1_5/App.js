import React, { useRef as useR } from "react";
import { SafeAreaView as SAV, ScrollView as SCV, Text as Txt, StyleSheet as StyleSh, View as V, ImageBackground as ImgB, Animated as Ani, useWindowDimensions as useWD } from "react-native";

const imagesArr = [
'https://images.wallpaperscraft.ru/image/single/bmw_avtomobil_bamper_191131_1280x720.jpg',
'https://images.wallpaperscraft.ru/image/single/mashina_seryj_mokryj_147750_1280x720.jpg',
'https://images.wallpaperscraft.ru/image/single/bmw_m3_bmw_avtomobil_901271_1280x720.jpg',
'https://images.wallpaperscraft.ru/image/single/nochnoj_gorod_vid_sverhu_ogni_goroda_134887_1280x720.jpg','https://images.wallpaperscraft.ru/image/single/domik_zima_sneg_134709_1280x720.jpg',
'https://cojo.ru/wp-content/uploads/2023/01/molodets-umnitsa-4.webp'
];

const MyComponent = () => {
  const scrollAnim = useR(new Ani.Value(0)).current;
  const { width: winWidth } = useWD();

  return (
    <SAV style={styles.container}>
      <V style={styles.mainContainer}>
        <SCV
          horizontal={true}
          style={styles.scrollStyle}
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={Ani.event([
            {
              nativeEvent: {
                contentOffset: {
                  x: scrollAnim
                }
              }
            }
          ])}
          scrollEventThrottle={1}
        >
          {imagesArr.map((image, imageIndex) => (
            <V style={{ width: winWidth, height: 250 }} key={imageIndex}>
              <ImgB source={{ uri: image }} style={styles.imageCard}>
                <V style={styles.textContent}>
                  <Txt style={styles.infoText}>
                    {"Lab1_5"}
                  </Txt>
                  <Txt style={styles.infoText}>
                  {"Image" + imageIndex}
                  </Txt>
                </V>
              </ImgB>
            </V>
          ))}
        </SCV>
        <V style={styles.dotContainer}>
          {imagesArr.map((image, imageIndex) => {
            const dotWidth = scrollAnim.interpolate({
              inputRange: [
                winWidth * (imageIndex - 1),
                winWidth * imageIndex,
                winWidth * (imageIndex + 1)
              ],
              outputRange: [8, 16, 8],
              extrapolate: "clamp"
            });

            return (
              <Ani.View key={imageIndex} style={[styles.dot, { width: dotWidth }]} />
            );
          })}
        </V>
      </V>
    </SAV>
  );
};

const styles = StyleSh.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#f0f0f0"
  },
  mainContainer: {
    height: 300,
    alignItems: "center",
    justifyContent: "center"
  },
  imageCard: {
    flex: 1,
    marginVertical: 4,
    marginHorizontal: 16,
    borderRadius: 10,
    overflow: "hidden",
    justifyContent: "center",
    alignItems: "center"
  },
  textContent: {
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    paddingHorizontal: 24,
    paddingVertical: 8,
    borderRadius: 5
  },
  infoText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold"
  },
  dotContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10
  },
  dot: {
    height: 8,
    width: 8,
    borderRadius: 4,
    backgroundColor: "#999",
    marginHorizontal: 4
  }
});

export default MyComponent;

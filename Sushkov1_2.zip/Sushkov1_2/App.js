import { StyleSheet, Text, View, Button, Alert } from 'react-native';

const MyCustomComponent = () => {
  return (
    <View style={styles.wrapper}>
      <Text style={styles.title}>Kolobok hanged himself =)</Text>
      <View style={styles.infoContainer}>
        <Text style={styles.publisher}>Книга "Правила двух минут"</Text>
        <Text style={styles.publisher}>Издательство "I dont know"</Text>
      </View>
      <View style={styles.contentContainer}>
        <Text style={styles.paragraph}>
          Это идеальный метод для решения всех тех небольших задач, которые решаются быстро, но, если откладываются, то требуют времени и умственных усилий. Вы освобождаете свой ум от “зависаний», которые лишают вас покоя.
Звучит это правило так: если перед вами стоит задача, которую вы можете выполнить менее чем за 2 минуты, выполните ее немедленно, а не откладывайте на потом.  Этот простой механизм имеет много преимуществ. Например, вы работаете и вдруг вспоминаете, что вам нужно срочно записаться на прием к врачу. Спросите себя: сможете ли вы сделать это менее чем за 2 минуты? Если да, то сделайте это, а вот если нет, запишите его в список дел. И так со всем, что угодно: ответить на письмо, позвонить в банк, запустить стиральную машину. 
        </Text>
        <Button 
          title="Read more..."
          color="green"
          onPress={() => Alert.alert("Button Clicked")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: { flex: 1, backgroundColor: '#F2F2F2', padding: 16 },
  title: { textAlign: 'center', fontSize: 24, fontWeight: 'bold', marginTop: 40, marginBottom: 20 },
  infoContainer: { backgroundColor: '#D3D3D3', padding: 12, alignItems: 'center', marginBottom: 20 },
  publisher: { textAlign: 'center' },
  contentContainer: { backgroundColor: '#A9A9A9', padding: 16 },
  paragraph: { fontSize: 16, marginBottom: 20 },
});

export default MyCustomComponent;
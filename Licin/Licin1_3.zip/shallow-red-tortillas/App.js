import { StyleSheet, Text, SafeAreaView, ScrollView, View, TextInput, Image, Button, Alert } from 'react-native'
const LotsOfStyles = () => {
return (
<View style={styles.screen}>
<Image source={require('./assets/welcome-neon-glow-dark-background-glowing-2560x1440-2068.jpg')} style={{ height: 235, resizeMode: 'center', marginTop: 70, alignSelf: 'center'}} />
<Text style={styles.title}>Добро пожаловать</Text>
<Text style={styles.text}>Приветствую вас в данном приложении. Здесь вы найдете все, что вам нужно</Text>
<Text style={styles.text}>Для поиска всего, что вам нужно, достаточно начать искать</Text>
<View style={[{ width: 'auto', position: 'absolute', top: 600, left: 80, right: 80}]}>
          <Button
            title="Далее"
            color="#FF8787"
          />
        </View>
</View>
);
};
const styles = StyleSheet.create({
screen: {
flex: 1
},
title: {
fontFamily: 'Geometria',
fontSize: 20,
fontWeight: 'bold',
marginTop: 60,
marginHorizontal: 30,
color: '#3A3A2'
},
text: {
fontFamily: 'Geometria',
fontSize: 16,
fontWeight: 'regular',
marginTop: 10,
marginHorizontal: 30,
color: '#3A3A2'
}
});
export default LotsOfStyles;
import {StyleSheet,Text,SafeAreaView,TouchableOpacity,StatusBar,} from 'react-native';

const Contact = ({id, name, phone, navigation}) => {
    return (
        <TouchableOpacity style={styles.contact_card}
                          onPress={() => {
                              navigation.navigate(
                                  'ProfileScreen',
                                  {
                                      id: {id},
                                      name: {name},
                                      phone: {phone},
                                      navigation: {navigation}
                                  })
                          }
                          }>
            <Text>{name}</Text>
        </TouchableOpacity>
    );
}


const Contacts = ({navigation}) => {
    return (
        <SafeAreaView style={styles.container}>
            <Contact
                id={1}
                name={'First'}
                phone={'+123456789'}
                navigation={navigation}
            />
            <Contact
                id={2}
                name={'Second'}
                phone={'+123456789'}
                navigation={navigation}
            />
            <Contact
                id={3}
                name={'Third'}
                phone={'+123456789'}
                navigation={navigation}
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: StatusBar.currentHeight,
    },
    scrollView: {
        flex: 1,
        marginHorizontal: 30,
        paddingVertical: 10,
        gap: 10,
    },
    text: {
        fontSize: 50,
    },
    contact_card: {
        padding: 20,
        margin: 10,
        borderWidth: 1,
        borderRadius: 8,
    }
});
export default Contacts
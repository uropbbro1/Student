import React, {useRef, useEffect} from "react";
import {
    SafeAreaView,
    ScrollView,
    Text,
    StyleSheet,
    View,
    Image,
    Animated,
    useWindowDimensions
} from "react-native";
import type {PropsWithChildren} from 'react';
import type {ViewStyle} from 'react-native';

const images = [
    'https://i.imgur.com/J4sRJkr.jpeg',
    'https://i.imgur.com/zgUfCvX.jpeg',
    'https://i.imgur.com/eLmmpdR.jpeg',
    'https://i.imgur.com/5MQY4YV.jpeg',
    'https://i.imgur.com/UEvlZER.jpeg'
]

const titles = ['Sleeping dog', 'Just a cat', 'Big and small cat', 'Big and small cat 2', 'Funny cat']

const text = ['Here is a Sleeping dog', 'Here is a Just a cat', 'Big and small cat', 'Big and small cat 2', 'Funny cat']

type FadeInViewProps = PropsWithChildren<{style: ViewStyle}>;

const FadeInView: React.FC<FadeInViewProps> = props => {
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 3000,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  return (
    <Animated.View
      style={{
        ...props.style,
        opacity: fadeAnim,
      }}>
      {props.children}
    </Animated.View>
  );
};

const AnimatedComponent = () => {

    const scrollX = useRef(new Animated.Value(0)).current;
    const {width: windowWidth} = useWindowDimensions();
    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.scrollContainer}>
                <ScrollView
                    horizontal={true}
                    pagingEnabled
                    showsHorizontalScrollIndicator={false}
                    onScroll={Animated.event([
                        {
                            nativeEvent: {
                                contentOffset: {
                                    x: scrollX
                                }
                            }
                        }
                    ])}
                    scrollEventThrottle={1}
                >
                    {images.map((image, imageIndex) => {
                        return (
                            <Animated.View
                                style={{
                                    width: windowWidth
                                }}
                            >
                            <FadeInView>
                                <Image source={{uri: image}} style={styles.picture}>
                                </Image>
                                <Text style={styles.title}>{titles[imageIndex]}</Text>
                                <Text style={styles.text}>{text[imageIndex]}</Text>
                                </FadeInView>
                            </Animated.View>
                        );
                    })}
                </ScrollView>
                <View style={styles.indicatorContainer}>
                    {images.map((image, imageIndex) => {
                        const width = scrollX.interpolate({
                            inputRange: [
                                windowWidth * (imageIndex - 1),
                                windowWidth * imageIndex,
                                windowWidth * (imageIndex + 1)
                            ],
                            outputRange: [8, 16, 8],
                            extrapolate: "clamp"

                        });
                        
                        return (
                            <Animated.View
                                key={imageIndex}
                                style={[styles.normalDot, {width}]}
                            />
                        ); 
                    })}
                </View>
            </View>
        </SafeAreaView>
    );
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginVertical: 60,
        alignItems: "center",
        justifyContent: "center"
    },
    scrollContainer: {
        alignItems: "center",
        justifyContent: "center"
    },
    picture: {
      height: 280,
      width: '100%',
      resizeMode: 'contain',
      marginTop: 70,
      alignSelf: 'center'
    },
    normalDot: {
        height: 8,
        width: 8,
        borderRadius: 4,
        backgroundColor: "pink",
        marginHorizontal: 4
    },
    indicatorContainer: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center"
    },
    title: {
fontFamily: 'Times New Roman',
fontSize: 30,
fontWeight: 'bold',
marginTop: 24,
marginHorizontal: 30,
color: '#3A3AB',
textAlign: 'center'
},
text: {
fontFamily: 'Geometria',
fontSize: 16,
fontWeight: 'regular',
marginTop: 10,
marginHorizontal: 30,
color: '#3A3AB'
}
});

export default AnimatedComponent
import React from 'react';
import { Button, View, Text, TextInput, StyleSheet, Alert } from 'react-native';

const AccessScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Welcome</Text>
        <Text style={styles.subtitle}>Please enter your credentials to continue</Text>

        <TextInput
          style={styles.input}
          placeholder="Username"
        />

        <TextInput
          style={styles.input}
          placeholder="Password"
          secureTextEntry={true}
        />

        <Button
          title="Log in"
          onPress={() => Alert.alert('Successful login!')}
        />

        <Button
          title="Sign up"
          onPress={() => navigation.navigate('RegisterScreen')}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: "#ffffff",
  },
  content: {
    width: 250,
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    margin: 5,
  },
  subtitle: {
    textAlign: 'center',
    color: 'gray',
    margin: 10,
  },
  input: {
    height: 40,
    marginVertical: 10,
    borderWidth: 1,
    padding: 10,
  },
});

export default AccessScreen;

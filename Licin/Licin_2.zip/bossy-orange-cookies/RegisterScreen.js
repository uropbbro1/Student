import { Button, View, Text, TextInput, StyleSheet, Alert } from 'react-native';

const RegisterScreen = () => {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Create Account</Text>
        <Text style={styles.subtitle}>Please enter your details to create an account</Text>

        <TextInput
          style={styles.input}
          placeholder="Username"
        />

        <TextInput
          style={styles.input}
          placeholder="Password"
          secureTextEntry={true}
        />

        <TextInput
          style={styles.input}
          placeholder="Confirm Password"
          secureTextEntry={true}
        />

        <Button
          title="Sign up"
          onPress={() => Alert.alert('Account created successfully!')}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: "#ffffff",
  },
  content: {
    width: 250,
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    margin: 5,
  },
  subtitle: {
    textAlign: 'center',
    color: 'gray',
    margin: 10,
  },
  input: {
    height: 40,
    marginVertical: 10,
    borderWidth: 1,
    padding: 10,
  },
});

export default RegisterScreen;

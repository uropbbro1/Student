import {StyleSheet, Text, View, TextInput, Button, Image, Alert, Pressable} from 'react-native';
import {useState} from "react";

const width_proportion = '100%';

const Login = ({navigation}) => {
    const [login, onChangeLogin] = useState('');
    const [password, onChangePassword] = useState('');
    const [onPassword, setOnPassword] = useState(false)
    const handlePasswordFocus = () => {
        setOnPassword(true)
    }
    const handlePasswordBlur = () => {
        setOnPassword(false)
    }

    const handleLogin = () => {
        if (login === 'admin' && password === 'admin') {
            Alert.alert('Sucess')
            navigation.navigate('ToDoList')
        } else {
            Alert.alert('Wrong login')
        }
    }

    return (
        <View style={styles.container}>
            {onPassword ?
                <Image style={styles.image}
                       source={require('../images/vector-lock-icon.jpg')}
                />
                :
                <Image style={styles.image}
                       source={require('../images/vector-lock-icon.jpg')}
                />
            }

            <Text style={styles.title}>
                Authorization
            </Text>
            <Text style={styles.description}>
                Enter you login and password
            </Text>
            <TextInput
                style={styles.input}
                onChangeText={onChangeLogin}
                value={login}
                placeholder="Email"
                keyboardType="email-address"
            />
            <TextInput
                style={styles.input}
                onChangeText={onChangePassword}
                onFocus={handlePasswordFocus}
                onBlur={handlePasswordBlur}
                value={password}
                placeholder="Password"
                secureTextEntry={true}
                keyboardType="invisible-password"
            />
            <Pressable style={styles.button}
                       onPress={() => handleLogin()}
            >
                <Text style={styles.text}>Login</Text>
            </Pressable>
        </View>

    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
        display: 'flex',
        alignItems: 'center'
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        marginTop: 20,
    },
    description: {
        textAlign: "center",
        marginBottom: 20
    },
    input: {
        width: width_proportion,
        height: 40,
        margin: 12,
        borderWidth: 1,
        padding: 10,
        borderRadius: 8,
    },
    item: {
        fontSize: 16,
        marginBottom: 5,
    },
    image: {
        width: 200,
        height: 200,
        marginEnd: 'auto',
        marginStart: 'auto',
    },
    button: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        paddingHorizontal: 32,
        borderRadius: 4,
        borderStyle: 'solid',
        backgroundColor: 'grey',
    },
});

export default Login;
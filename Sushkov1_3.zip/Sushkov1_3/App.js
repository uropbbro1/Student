import { StyleSheet, Text, View, Image, Button, Alert } from 'react-native';

const CustomWelcomeComponent = () => {
  const handleButtonPress = () => {
    Alert.alert('Button Clicked!');
  };

  return (
    <View style={styles.container}>
      <Image source={require('./assets/123.png')} style={styles.image} />
      <Text style={styles.title}>Веганский рай!</Text>
      <Text style={styles.description}>Здесь вы найдете самые свежие и качественные продукты растительного происхождения.</Text>
      <Text style={styles.description}>Добро пожаловать в мир вкусных и полезных веганских продуктов!</Text>
      <View style={styles.buttonContainer}>
        <Button
          title="Get Started"
          color="#FF5733"
          onPress={handleButtonPress} 
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  image: {
    height: 285,
    resizeMode: 'contain',
    marginTop: 70,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 20,
    color: '#333',
  },
  description: {
    fontSize: 16,
    marginTop: 10,
    color: '#333',
    textAlign: 'center',
  },
  buttonContainer: {
    marginTop: 40,
    width: '50%',
  },
});

export default CustomWelcomeComponent;

